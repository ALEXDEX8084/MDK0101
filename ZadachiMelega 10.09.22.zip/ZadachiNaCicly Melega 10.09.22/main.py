# Выполнил студент группы ИСП.20А Мелега Алексей
# Задание №1
print('Введите количество секунд:')
a = int(input())
while a != -1:
    print('Осталось секунд:', a)
    a -= 1
print('Пуск')
# Задание №2
print('Введите высоту пирамиды:')
n = int(input())
space = n-1
star = 1
for i in range(1, n + 1):
    print(" " * space + '*' * star)
    space -= 1
    star += 2
# Задание №3
print('Введите число тестируемых людей:')
p = int(input())
averiq = 0
iqsumm = 0
isp = 0
while p != isp:
    print('Введите IQ респондента:')
    iq = int(input())
    iqsumm += iq
    isp += 1
    averiq = iqsumm/isp

    if iq == averiq:
        print(0)
    elif iq > averiq:
        print('>')
    else:
        print('<')
# Задание №4
t = 0
day = 0
while t <= 23:
    print('Введите температуру за день:')
    t = float(input())
    day += 1
    if (t >= 23):
        week = day // 7
        print(week)
# Задание №5
s = 0
while s != 1:
    print('Введите пароль:')
    password = input()
    if len(password) < 8:
        print('Пароль слишком короткий!')
    elif '123' in password:
        print('Простой!')
    else:
        s = 1
s = 0
while s != 1:
    print('Повторите пароль:')
    repeatpas = input()
    if repeatpas != password:
        print('Пароль не совпадает!')
    else:
        print('OK')
        break
# Задание №6
print('Введите натуральное число n:')
count = 0
num = 0
ss = 0
num = int(input())
while ss != 1:
    if num % 2 != 0:
       num = 3 * num + 1
       count += 1
    else:
        num = num / 2
        count += 1
    if num == 1:
        break
print(count)
# Задание №7
print('Введите цену приобретённых товаров')
print('Введите любое отрицательное число для завершения ввода')
price = 0
sum = 0
while price > -1:
    price = float(input())
    if price <= -1:
        break
    elif price > 500:
        price = price - price * 0.07
        sum += price
    else:
        sum += price
print(sum)